class AppUser {
  final String id;
  final String firstName;
  final String secondName;
  final String phone;
  final String email;
  final String? password;
  final bool isAdmin;

  AppUser({
    required this.id,
    required this.firstName,
    required this.secondName,
    required this.phone,
    required this.email,
    this.password,
    this.isAdmin = false,
  });

  String get fullName => '$firstName $secondName';
}
