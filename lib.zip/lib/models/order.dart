class Order {
  final String orderId;
  final String customerName;
  final String status;
  final double totalAmount;
  final DateTime date;

  Order({
    required this.orderId,
    required this.customerName,
    required this.status,
    required this.totalAmount,
    required this.date,
  });
}
