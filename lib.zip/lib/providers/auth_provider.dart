import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';
import '../models/user.dart';

enum AuthStatus { authenticated, guest, admin, unauthenticated }

class AuthState {
  final AuthStatus status;
  final AppUser? user;

  AuthState({required this.status, this.user});

  factory AuthState.initial() => AuthState(status: AuthStatus.unauthenticated);
}

class AuthNotifier extends StateNotifier<AuthState> {
  AuthNotifier() : super(AuthState.initial());

  void loginAsAdmin() {
    state = AuthState(
      status: AuthStatus.admin,
      user: AppUser(
        id: 'admin_1',
        firstName: 'System',
        secondName: 'Admin',
        phone: '0000000000',
        email: 'admin@shamsalkananah.com',
        isAdmin: true,
      ),
    );
  }

  void loginAsUser(AppUser user) {
    state = AuthState(status: AuthStatus.authenticated, user: user);
  }

  void loginAsGuest() {
    state = AuthState(status: AuthStatus.guest);
  }

  void logout() {
    state = AuthState.initial();
  }
}

final authProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  return AuthNotifier();
});

class RegisteredUsersNotifier extends StateNotifier<List<AppUser>> {
  RegisteredUsersNotifier() : super([]);

  void registerUser(AppUser user) {
    state = [...state, user];
  }
}

final registeredUsersProvider = StateNotifierProvider<RegisteredUsersNotifier, List<AppUser>>((ref) {
  return RegisteredUsersNotifier();
});
