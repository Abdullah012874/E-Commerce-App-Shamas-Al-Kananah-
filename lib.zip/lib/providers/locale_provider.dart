import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';

enum AppLocale { english, arabic }

class LocaleNotifier extends StateNotifier<AppLocale> {
  LocaleNotifier() : super(AppLocale.english);

  void toggleLocale() {
    state = state == AppLocale.english ? AppLocale.arabic : AppLocale.english;
  }

  void setLocale(AppLocale locale) {
    state = locale;
  }
}

final localeProvider = StateNotifierProvider<LocaleNotifier, AppLocale>((ref) {
  return LocaleNotifier();
});

// A simple dictionary for translation
final translationProvider = Provider<Map<String, String>>((ref) {
  final locale = ref.watch(localeProvider);
  if (locale == AppLocale.arabic) {
    return {
      'Home': 'الرئيسية',
      'Search': 'بحث',
      'Cart': 'عربة التسوق',
      'Wishlist': 'قائمة الرغبات',
      'Profile': 'الملف الشخصي',
      'Categories': 'الفئات',
      'Popular Products': 'منتجات شائعة',
      'Electrical': 'الكهرباء',
      'Plumbing': 'السباكة',
      'Hardware': 'المعدات',
      'Tools': 'أدوات',
      // Add more as needed
    };
  }
  return {
    'Home': 'Home',
    'Search': 'Search',
    'Cart': 'Cart',
    'Wishlist': 'Wishlist',
    'Profile': 'Profile',
    'Categories': 'Categories',
    'Popular Products': 'Popular Products',
    'Electrical': 'Electrical',
    'Plumbing': 'Plumbing',
    'Hardware': 'Hardware',
    'Tools': 'Tools',
  };
});
