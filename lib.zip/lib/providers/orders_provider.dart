import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';
import '../models/order.dart';
import '../data/dummy_data.dart';

class OrdersNotifier extends StateNotifier<List<Order>> {
  OrdersNotifier() : super(DummyData.recentOrders);

  void addOrder(Order order) {
    state = [order, ...state];
  }

  void updateOrderStatus(String orderId, String newStatus) {
    state = [
      for (final order in state)
        if (order.orderId == orderId)
          Order(
            orderId: order.orderId,
            customerName: order.customerName,
            status: newStatus,
            totalAmount: order.totalAmount,
            date: order.date,
          )
        else
          order,
    ];
  }
}

final ordersProvider = StateNotifierProvider<OrdersNotifier, List<Order>>((ref) {
  return OrdersNotifier();
});
