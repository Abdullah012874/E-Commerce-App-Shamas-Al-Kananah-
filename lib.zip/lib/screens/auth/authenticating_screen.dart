import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../utils/app_colors.dart';
import '../../providers/auth_provider.dart';
import '../main_layout.dart';

class AuthenticatingScreen extends ConsumerStatefulWidget {
  final String username;
  final String password;

  const AuthenticatingScreen({
    super.key,
    required this.username,
    required this.password,
  });

  @override
  ConsumerState<AuthenticatingScreen> createState() => _AuthenticatingScreenState();
}

class _AuthenticatingScreenState extends ConsumerState<AuthenticatingScreen> {
  @override
  void initState() {
    super.initState();
    _authenticate();
  }

  Future<void> _authenticate() async {
    // Simulate network delay
    await Future.delayed(const Duration(seconds: 2));
    
    if (!mounted) return;

    final username = widget.username;
    final password = widget.password;

    if (username == 'admin' && password == 'admin') {
      ref.read(authProvider.notifier).loginAsAdmin();
      _navigateToHome();
      return;
    } 

    final registeredUsers = ref.read(registeredUsersProvider);
    try {
      final user = registeredUsers.firstWhere(
        (u) => (u.email == username || u.firstName == username) && u.password == password,
      );
      ref.read(authProvider.notifier).loginAsUser(user);
      _navigateToHome();
    } catch (e) {
      // Failed, pop back to login screen with error message
      Navigator.of(context).pop('Invalid credentials. Please register or try again.');
    }
  }

  void _navigateToHome() {
    // Navigate to Home and remove all previous routes from stack (like LoginScreen)
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const MainLayout()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: AppColors.primary, // Same as app drawer header
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(
              color: Colors.white,
              strokeWidth: 3,
            ),
            SizedBox(height: 24),
            Text(
              'Authenticating...',
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.2,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
