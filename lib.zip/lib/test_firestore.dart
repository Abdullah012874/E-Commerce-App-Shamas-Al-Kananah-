import 'package:cloud_firestore/cloud_firestore.dart';

Future<void> addTestData() async {
  await FirebaseFirestore.instance.collection('test').add({
    'name': 'Fasih',
    'message': 'Firebase connected successfully'
  });
}